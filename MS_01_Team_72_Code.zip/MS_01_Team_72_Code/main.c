/**
 * Copyright (c) 2020 Raspberry Pi (Trading) Ltd.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include <stdio.h>
#include "pico/stdlib.h"
#include "led.h"

int main() {
    // Initialize stdio and the LEDs
    stdio_init_all();
    
    // Start the LED sequence
    run_led_sequence();

    return 0;
}



