#include "led.h"

// GPIOs for Red, Green, and Blue LEDs
#define RED_LED 14
#define GREEN_LED 15
#define BLUE_LED 13

// Initialize the specified LED pin as output
void LED_Init(uint8_t led_pin) {
    gpio_init(led_pin);
    gpio_set_dir(led_pin, GPIO_OUT);
}

// Turn the specified LED ON
void LED_On(uint8_t led_pin) {
    if (led_pin == BLUE_LED) {
        // Negative logic for Blue LED
        gpio_put(led_pin, 0);
    } else {
        // Positive logic for Red and Green LEDs
        gpio_put(led_pin, 1);
    }
}

// Turn the specified LED OFF
void LED_Off(uint8_t led_pin) {
    if (led_pin == BLUE_LED) {
        // Negative logic for Blue LED
        gpio_put(led_pin, 1);
    } else {
        // Positive logic for Red and Green LEDs
        gpio_put(led_pin, 0);
    }
}

// Initialize the LEDs
void init_leds() {
    LED_Init(RED_LED);
    LED_Init(GREEN_LED);
    LED_Init(BLUE_LED);
}

// Run the full LED sequence
void run_led_sequence(void) {
    init_leds();

    while (true) {
        // All LEDs off for the first 5 seconds
        LED_Off(RED_LED);
        LED_Off(GREEN_LED);
        LED_Off(BLUE_LED);
        sleep_ms(5000);

        // Red LED ON for 1 second, then OFF
        LED_On(RED_LED);
        sleep_ms(1000);
        LED_Off(RED_LED);

        // Green LED ON for 1 second, then OFF
        LED_On(GREEN_LED);
        sleep_ms(1000);
        LED_Off(GREEN_LED);

        // Blue LED ON for 1 second, then OFF
        LED_On(BLUE_LED);
        sleep_ms(1000);
        LED_Off(BLUE_LED);

        // All LEDs ON for 2 seconds, then OFF
        LED_On(RED_LED);
        LED_On(GREEN_LED);
        LED_On(BLUE_LED);
        sleep_ms(2000);

        // Turn all LEDs off
        LED_Off(RED_LED);
        LED_Off(GREEN_LED);
        LED_Off(BLUE_LED);
    }
}
