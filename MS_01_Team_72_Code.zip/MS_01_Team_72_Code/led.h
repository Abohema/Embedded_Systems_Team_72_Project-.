#ifndef LED_DRIVER_H
#define LED_DRIVER_H

#include "pico/stdlib.h"

// Initialize the specified LED pin as output
void LED_Init(uint8_t led_pin);

// Turn the specified LED ON
void LED_On(uint8_t led_pin);

// Turn the specified LED OFF
void LED_Off(uint8_t led_pin);

// Run the full LED sequence (encapsulated logic)
void run_led_sequence(void);

#endif // LED_DRIVER_H
