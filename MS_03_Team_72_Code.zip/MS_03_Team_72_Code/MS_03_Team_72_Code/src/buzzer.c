#include "pico/stdlib.h"
#include "buzzer.h"

#define BUZZER_PIN 20 // GPIO pin for the buzzer

void buzzer_init() {
    gpio_init(BUZZER_PIN);
    gpio_set_dir(BUZZER_PIN, GPIO_OUT);
}

void buzzer_on() {
    gpio_put(BUZZER_PIN, 1); // Set the pin HIGH to activate the buzzer
}

void buzzer_off() {
    gpio_put(BUZZER_PIN, 0); // Set the pin LOW to deactivate the buzzer
}

void buzzer_beep(int duration_ms) {
    buzzer_on();
    sleep_ms(duration_ms);
    buzzer_off();
}