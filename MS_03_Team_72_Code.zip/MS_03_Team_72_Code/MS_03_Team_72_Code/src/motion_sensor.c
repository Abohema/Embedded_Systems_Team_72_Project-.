#include <stdio.h>
#include "motion_sensor.h"
#include "pico/stdlib.h"

#define PIR_SENSOR_PIN 21 // Updated GPIO pin for the motion sensor

void motion_sensor_init() {
    gpio_init(PIR_SENSOR_PIN);

    gpio_set_dir(PIR_SENSOR_PIN, GPIO_IN);
}

bool detect_motion() {
    // printf("Motion detected: %d\n", gpio_get(PIR_SENSOR_PIN));
    return gpio_get(PIR_SENSOR_PIN); // Returns 1 if motion is detected
    
}