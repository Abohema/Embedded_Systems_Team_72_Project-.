#ifndef BUZZER_H
#define BUZZER_H


// Initialize the buzzer
void buzzer_init();

// Turn the buzzer ON
void buzzer_on();

// Turn the buzzer OFF
void buzzer_off();

// Make the buzzer beep for a specified duration (in ms)
void buzzer_beep(int duration_ms);

#endif // BUZZER_H