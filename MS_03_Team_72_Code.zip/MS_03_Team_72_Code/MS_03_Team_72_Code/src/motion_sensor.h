#ifndef MOTION_SENSOR_H
#define MOTION_SENSOR_H
#include <stdbool.h>
#include <stdio.h>

// Initialize the motion sensor
void motion_sensor_init();
// Detect motion (returns true if motion detected)
bool detect_motion();

#endif