#include "pico/stdlib.h"
#include "leds.h"

#define RED_LED 14
#define GREEN_LED 15

void LED_Init(uint8_t led_pin) {
    gpio_init(led_pin);
    gpio_set_dir(led_pin, GPIO_OUT);
}

void LED_On(uint8_t led_pin) {
    gpio_put(led_pin, 1);
}

void LED_Off(uint8_t led_pin) {
    gpio_put(led_pin, 0);
}

void init_leds() {
    LED_Init(RED_LED);
    LED_Init(GREEN_LED);
}

void update_leds(bool rain_detected) {
    if (rain_detected) {
        LED_On(RED_LED);
        LED_Off(GREEN_LED);
    } else {
        LED_Off(RED_LED);
        LED_On(GREEN_LED);
    }
}