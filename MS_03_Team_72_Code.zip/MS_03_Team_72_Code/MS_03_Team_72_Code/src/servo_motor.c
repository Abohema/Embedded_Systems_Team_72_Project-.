#include "hardware/pwm.h"
#include "hardware/clocks.h"
#include "pico/stdlib.h"
#include "servo_motor.h"

void servo_motor_init(Servo *servo, uint8_t gp) {
    servo->gpio_pin = gp;

    // Initialize GPIO for PWM
    gpio_init(gp);
    gpio_set_function(gp, GPIO_FUNC_PWM);
    pwm_set_gpio_level(gp, 0);

    // Get the PWM slice number
    servo->slice_num = pwm_gpio_to_slice_num(gp);

    // Get system clock frequency and compute divider for 50 Hz
    uint32_t clk = clock_get_hz(clk_sys);
    uint32_t div = clk / (20000 * 50);

    // Clamp divider to valid range
    if (div < 1) div = 1;
    if (div > 255) div = 255;

    // Configure PWM
    pwm_config config = pwm_get_default_config();
    pwm_config_set_clkdiv(&config, (float)div);
    pwm_config_set_wrap(&config, 20000); // Set wrap to achieve 20 ms period (50 Hz)

    // Load configuration and enable PWM
    pwm_init(servo->slice_num, &config, false);
    pwm_set_enabled(servo->slice_num, true);
}

void move_servo(Servo *servo, float degree) {
    if (degree > 180.0 || degree < 0.0) {
        // printf("Invalid degree: %.2f\n", degree);
        return;
    }

    // Calculate duty cycle for the given angle
    int duty = (((float)(ROTATE_180 - ROTATE_0) / 180.0) * degree) + ROTATE_0;
    // printf("PWM for %.2f° is %d duty\n", degree, duty);

    // Set duty cycle
    pwm_set_gpio_level(servo->gpio_pin, duty);
}