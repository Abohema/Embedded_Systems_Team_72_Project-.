#ifndef LDR_H
#define LDR_H
#include <stdint.h>

// Initialize the LDR sensor
void LDR_init();

// Read the light intensity as an ADC value
uint16_t read_LDR();

#endif // LDR_H