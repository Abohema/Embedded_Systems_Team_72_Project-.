#ifndef SERVO_MOTOR_H
#define SERVO_MOTOR_H
#include <stdio.h>
#include <stdint.h>
#include <stdio.h>
#include <stdbool.h>
#define ROTATE_0 500   // Duty cycle for 0° position
#define ROTATE_180 2500 // Duty cycle for 180° position

typedef struct {
    uint8_t gpio_pin;
    uint slice_num;
} Servo;

void servo_motor_init(Servo *servo, uint8_t gp);
void move_servo(Servo *servo, float degree);

#endif // SERVO_MOTOR_H