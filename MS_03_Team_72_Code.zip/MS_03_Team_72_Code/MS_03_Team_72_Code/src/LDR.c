#include "LDR.h"
#include "hardware/adc.h"

#define LDR_PIN 26 // ADC channel for the LDR (GPIO 26)

void LDR_init() {
    adc_init();                   // Initialize ADC hardware
    adc_gpio_init(LDR_PIN);       // Enable GPIO pin for ADC input
    adc_select_input(0);          // Select ADC channel 0 (GPIO 26)
}

uint16_t read_LDR() {
    return adc_read(); // Read the ADC value (0–4095)
}