#include "pico/stdlib.h"
#include "hardware/adc.h"
#include "rain_sensor.h"
#define RAIN_SENSOR_PIN 27 // GPIO Pin for rain sensor

void rain_sensor_init() {
    adc_init();
    adc_gpio_init(RAIN_SENSOR_PIN);
    adc_select_input(0); // Select ADC0
}

uint16_t read_rain_intensity() {
    uint16_t raw_value = adc_read();
    // printf("Rain intensity: %d\n", raw_value);
    return raw_value; 
}