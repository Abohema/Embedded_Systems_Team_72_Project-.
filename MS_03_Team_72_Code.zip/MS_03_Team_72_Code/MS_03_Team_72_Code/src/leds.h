#ifndef LED_DRIVER_H
#define LED_DRIVER_H
#include <stdint.h>

// Function to initialize an LED pin
void LED_Init(uint8_t led_pin);

// Function to turn an LED ON
void LED_On(uint8_t led_pin);

// Function to turn an LED OFF
void LED_Off(uint8_t led_pin);

// Function to initialize both LEDs
void init_leds();

// Function to update LEDs based on rain detection logic
void update_leds(bool rain_detected);

#endif // LED_DRIVER_H