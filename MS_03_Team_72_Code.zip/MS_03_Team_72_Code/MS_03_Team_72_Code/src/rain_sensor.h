#ifndef RAIN_SENSOR_H
#define RAIN_SENSOR_H
#include <stdio.h>
#include <stdint.h>

void rain_sensor_init();
uint16_t read_rain_intensity();

#endif